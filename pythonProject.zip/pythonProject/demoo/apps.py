from django.apps import AppConfig


class DemooConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'demoo'
