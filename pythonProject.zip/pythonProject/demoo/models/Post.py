from django.db import models
from .user import User

class Post(models.Model):
    title=models.CharField(max_length=50)
    photo = models.ImageField(upload_to='postimages/',null=True, blank=True)
    category = models.CharField(max_length=40, null=True, blank=True)
    summery = models.CharField(max_length=200,null=True, blank=True)
    content = models.CharField(max_length=2000)
    usertype = models.CharField(max_length=20, default='patient')
    userid = models.ForeignKey(User, on_delete=models.CASCADE)
    drafts = models.BooleanField(default=True)

    def regis(self):
        self.save()
    
    @staticmethod
    def get_draftpost_by_id(ids):
        return Post.objects.filter(userid_id=ids).filter(drafts=True)
    
    @staticmethod
    def get_docpost():
        return Post.objects.filter(usertype="doctor")
    
    @staticmethod
    def get_all_posts(cat):
        return Post.objects.filter(drafts=False).filter(category=cat)