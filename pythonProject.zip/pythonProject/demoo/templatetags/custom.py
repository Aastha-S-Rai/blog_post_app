from django import template
import re

register = template.Library()


@register.filter(name='splitt')
def splitt(strr):
    res=len(strr)
    str1=strr
    if res > 15:
        l= str1.split()[:15]
        ret=""
        for i in l:
            ret+=i
            ret+=" "
        return ret
    else:
        return strr

